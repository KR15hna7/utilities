targetScope = 'resourceGroup'

@description('Azure region for all resources in this module.')
param location string

@description('Environment name used in resource naming.')
param environment string

@description('Application name used in resource naming.')
param applicationName string

@description('Division name used in resource naming.')
param divisionName string

@description('Description for the Foundry project.')
param foundryProjectDescription string

@description('Model name to deploy.')
param modelName string

@description('Model version to deploy.')
param modelVersion string

@description('Deployment SKU name. Common values: Standard, GlobalStandard, DataZoneStandard.')
param modelDeploymentSkuName string

@description('Deployment capacity (tokens-per-minute unit).')
@minValue(1)
param modelDeploymentCapacity int

@description('Tags applied to created resources.')
param tags object = {}

var foundryAccountName = 'ais-${divisionName}-${applicationName}-${environment}'
var foundryProjectName = 'aip-${divisionName}-${applicationName}-${environment}'
var modelDeploymentName = 'dep-${divisionName}-${applicationName}-${environment}'
var foundryProjectDisplayName = '${divisionName}-${applicationName}-${environment}'
var foundryCustomSubdomain = toLower('ais-${divisionName}-${applicationName}-${environment}')

module foundryAccount 'br/public:avm/res/cognitive-services/account:0.14.2' = {
  name: 'foundry-account-${uniqueString(resourceGroup().id, foundryAccountName)}'
  params: {
    kind: 'AIServices'
    name: foundryAccountName
    location: location
    sku: 'S0'
    allowProjectManagement: true
    customSubDomainName: foundryCustomSubdomain
    publicNetworkAccess: 'Enabled'
    tags: tags
  }
}

resource foundryAccountExisting 'Microsoft.CognitiveServices/accounts@2025-06-01' existing = {
  name: foundryAccountName
}

resource foundryProject 'Microsoft.CognitiveServices/accounts/projects@2025-06-01' = {
  parent: foundryAccountExisting
  name: foundryProjectName
  location: location
  tags: tags
  properties: {
    displayName: foundryProjectDisplayName
    description: foundryProjectDescription
  }
  dependsOn: [
    foundryAccount
  ]
}

resource modelDeployment 'Microsoft.CognitiveServices/accounts/deployments@2025-06-01' = {
  parent: foundryAccountExisting
  name: modelDeploymentName
  tags: tags
  sku: {
    name: modelDeploymentSkuName
    capacity: modelDeploymentCapacity
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: modelName
      version: modelVersion
    }
    versionUpgradeOption: 'OnceNewDefaultVersionAvailable'
  }
  dependsOn: [
    foundryAccount
  ]
}

output foundryAccountId string = foundryAccount.outputs.resourceId
output foundryProjectId string = foundryProject.id
output modelDeploymentId string = modelDeployment.id
