# Azure AI Foundry + GPT-5o-mini Bicep Deployment

This repository contains a generic Bicep deployment that:

- Creates a resource group (subscription scope)
- Creates an Azure AI Foundry account (AIServices)
- Creates a Foundry project under that account
- Creates a GPT-5o-mini model deployment using a zone-capable SKU
- Runs through Azure DevOps pipeline using an Azure service connection

## Naming And Tagging Rules

The templates enforce these conventions:

- Resource group name: `rg-<DivisionName>-<ApplicationName>-<environment>`
- Foundry account name: `ais-<DivisionName>-<ApplicationName>-<environment>`
- Foundry project name: `aip-<DivisionName>-<ApplicationName>-<environment>`
- Model deployment name: `dep-<DivisionName>-<ApplicationName>-<environment>`

Every created resource (including the resource group) gets exactly these tags:

- `ApplicationName`
- `DivisionName`
- `Environment`

## Files

- `main.bicep`: Subscription-scope entry point
- `modules/foundry-resources.bicep`: Resource-group-scope Foundry resources
- `main.bicepparam`: Example/default parameters
- `main.dev.bicepparam`: Dev environment parameters
- `main.test.bicepparam`: Test environment parameters
- `main.prod.bicepparam`: Prod environment parameters
- `azure-pipelines.yml`: Azure DevOps pipeline

## Important Parameters

In each environment file (`main.dev.bicepparam`, `main.test.bicepparam`, `main.prod.bicepparam`) update these values before deployment:

- `environment`
- `applicationName`
- `divisionName`
- `modelVersion` (must be valid in target region)
- `modelDeploymentSkuName`

`modelDeploymentSkuName` examples:

- `Standard`
- `GlobalStandard`
- `DataZoneStandard`

For your request, default is set to `DataZoneStandard`.

## Pipeline Setup

1. In Azure DevOps, create a service connection with subscription-level access.
2. In `azure-pipelines.yml`, set `serviceConnectionDev`, `serviceConnectionTest`, and `serviceConnectionProd`.
3. Run pipeline with the `environment` parameter (`dev`, `test`, or `prod`).
4. The pipeline automatically uses the matching parameter file (`main.<environment>.bicepparam`).

The pipeline executes:

- `az deployment sub create --location <deploymentLocation> --template-file main.bicep --parameters main.<environment>.bicepparam --parameters environment=<environment>`

## Notes

- Some model/version/SKU combinations are region-specific. If deployment fails, update `location`, `modelVersion`, or `modelDeploymentSkuName`.
- This template uses Azure Verified Modules (AVM) where available:
  - `br/public:avm/res/resources/resource-group:0.4.3`
  - `br/public:avm/res/cognitive-services/account:0.14.2`
