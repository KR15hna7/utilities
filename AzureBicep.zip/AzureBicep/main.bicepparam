using './main.bicep'

param location = 'eastus2'
param environment = 'dev'
param applicationName = 'sentimentAnalysis'
param divisionName = 'eC'
param foundryProjectDescription = 'Foundry project for sentiment analysis in dev.'
param modelName = 'gpt-5o-mini'
param modelVersion = '2025-01-01'
param modelDeploymentSkuName = 'DataZoneStandard'
param modelDeploymentCapacity = 10
