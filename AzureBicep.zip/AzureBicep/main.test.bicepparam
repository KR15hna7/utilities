using './main.bicep'

param location = 'eastus2'
param environment = 'test'
param applicationName = 'sentimentAnalysis'
param divisionName = 'eC'
param foundryProjectDescription = 'Foundry project for sentiment analysis in test.'
param modelName = 'gpt-5o-mini'
param modelVersion = '2025-01-01'
param modelDeploymentSkuName = 'DataZoneStandard'
param modelDeploymentCapacity = 10
