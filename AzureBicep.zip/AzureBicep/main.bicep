targetScope = 'subscription'

@description('Azure region for the resource group and Foundry resources (for example: eastus2).')
param location string

@description('Environment name used in naming and tagging (for example: dev, test, prod).')
@allowed([
  'dev'
  'test'
  'prod'
])
param environment string

@description('Application name used in naming and tagging.')
param applicationName string = 'sentimentAnalysis'

@description('Division name used in naming and tagging.')
param divisionName string = 'eC'

@description('Description for the Foundry project.')
param foundryProjectDescription string = 'Azure AI Foundry project for ${applicationName} (${environment}).'

@description('Model name to deploy.')
param modelName string = 'gpt-5o-mini'

@description('Model version to deploy. Set to a region-supported version.')
param modelVersion string

@description('Deployment SKU name. Common values: Standard, GlobalStandard, DataZoneStandard.')
param modelDeploymentSkuName string = 'DataZoneStandard'

@description('Deployment capacity (tokens-per-minute unit).')
@minValue(1)
param modelDeploymentCapacity int = 10

var resourceGroupName = 'rg-${divisionName}-${applicationName}-${environment}'
var requiredTags = {
  ApplicationName: applicationName
  DivisionName: divisionName
  Environment: environment
}

module rg 'br/public:avm/res/resources/resource-group:0.4.3' = {
  name: 'rg-${uniqueString(subscription().id, resourceGroupName)}'
  params: {
    name: resourceGroupName
    location: location
    tags: requiredTags
  }
}

module foundry './modules/foundry-resources.bicep' = {
  name: 'foundry-${uniqueString(resourceGroupName, divisionName, applicationName, environment)}'
  scope: resourceGroup(resourceGroupName)
  dependsOn: [
    rg
  ]
  params: {
    location: location
    environment: environment
    applicationName: applicationName
    divisionName: divisionName
    foundryProjectDescription: foundryProjectDescription
    modelName: modelName
    modelVersion: modelVersion
    modelDeploymentSkuName: modelDeploymentSkuName
    modelDeploymentCapacity: modelDeploymentCapacity
    tags: requiredTags
  }
}

output resourceGroupId string = rg.outputs.resourceId
output foundryAccountId string = foundry.outputs.foundryAccountId
output foundryProjectId string = foundry.outputs.foundryProjectId
output modelDeploymentId string = foundry.outputs.modelDeploymentId
